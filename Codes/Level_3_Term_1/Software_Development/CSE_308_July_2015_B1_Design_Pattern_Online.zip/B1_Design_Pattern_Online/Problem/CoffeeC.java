public class CoffeeC extends Coffee
{
}
