public class CoffeeB extends Coffee
{
    public void addSugar() throws Exception
    {
        throw new Exception();
    }
}
