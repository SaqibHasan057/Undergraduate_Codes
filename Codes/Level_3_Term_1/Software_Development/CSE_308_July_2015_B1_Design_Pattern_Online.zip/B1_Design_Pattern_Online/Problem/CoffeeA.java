public class CoffeeA extends Coffee
{
}
