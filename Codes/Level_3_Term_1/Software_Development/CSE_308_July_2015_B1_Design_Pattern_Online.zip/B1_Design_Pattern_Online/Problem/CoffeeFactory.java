public class CoffeeFactory
{
    public Coffee produceCoffee(String type) throws Exception
    {
        Coffee coffee = createCoffee(type);
        coffee.addMilk();
        addSugar(coffee);
        coffee.addCaffein();
        return coffee;
    }
}
