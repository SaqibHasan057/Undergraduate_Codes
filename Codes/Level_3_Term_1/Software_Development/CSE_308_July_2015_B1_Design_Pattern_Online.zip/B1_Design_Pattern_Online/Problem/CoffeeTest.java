public class CoffeeTest
{    
    public static void main(String [] args)
    {
        try{
            CoffeeFactory cf = CoffeeFactory.getCoffeFactory();
            Coffee a = cf.produceCoffee("CoffeeA");
            a.print();
            Coffee b = cf.produceCoffee("CoffeeB");
            b.print();
            Coffee c = cf.produceCoffee("CoffeeC");
            c.print();
        } catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
