public abstract class Coffee
{
    public boolean hasMilk = false;
    public boolean hasSugar = false;
    public boolean hasCaffein = false;
    public String name;
    public abstract void addMilk();
    public abstract void addSugar() throws Exception;
    public abstract void addCaffein();
    public void print()
    {
        System.out.println(name + ": " + hasMilk + ", " + hasSugar + ", " + hasCaffein);
    }
}
