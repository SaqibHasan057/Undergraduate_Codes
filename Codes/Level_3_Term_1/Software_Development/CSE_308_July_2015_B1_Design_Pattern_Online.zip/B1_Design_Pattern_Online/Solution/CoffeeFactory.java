public class CoffeeFactory
{
    private static CoffeeFactory factory;
    private CoffeeFactory () {
        //[JVMInstance|-instance:JVMInstance|-JVMInstance();+getInstance():JVMInstance]
        /*[StudentAdmissionCommittee||+createStudent()]<>-creates>[Student], [Student|-name:string;-studentId:string|+register()], [BScStudent||+register()]-implements>[Student], [MScStudent||+register()]-implements>[Student], [PhDStudent||+register()]-implements>[Student]
        */
    }
    public synchronized static CoffeeFactory getCoffeFactory()
    {
        if(factory == null)
        {
            factory = new CoffeeFactory();
        }
        return factory;
    }
    private Coffee createCoffee(String type) throws Exception
    {
        if(type.equals("CoffeeA"))
        {
            return new CoffeeA();
        }
        else if(type.equals("CoffeeB"))
        {
            return new CoffeeB();
        }
        else if(type.equals("CoffeeC"))
        {
            return new CoffeeC();
        }
        else
        {
            throw new Exception();
        }
    }
    public void addSugar(Coffee coffee) throws Exception
    {
        if(coffee.name.equals("CoffeeB"))
        {
            //do nothing
        }
        else
        {
            coffee.addSugar();
        }
    }
    public Coffee produceCoffee(String type) throws Exception
    {
        Coffee coffee = createCoffee(type);
        coffee.addMilk();
        addSugar(coffee);
        coffee.addCaffein();
        return coffee;
    }
}
