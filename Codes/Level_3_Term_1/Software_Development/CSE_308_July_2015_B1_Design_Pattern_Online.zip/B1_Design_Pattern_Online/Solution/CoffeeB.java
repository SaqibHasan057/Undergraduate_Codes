public class CoffeeB extends Coffee
{
    public void addMilk()
    {
        hasMilk = true;
    }
    public void addSugar() throws Exception
    {
        throw new Exception();
    }
    public void addCaffein()
    {
        hasCaffein = true;
    }
    public CoffeeB()
    {
        this.name = "CoffeeB";
    }
}
