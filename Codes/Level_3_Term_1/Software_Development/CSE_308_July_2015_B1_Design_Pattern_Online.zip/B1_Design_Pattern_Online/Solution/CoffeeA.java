public class CoffeeA extends Coffee
{
    public void addMilk()
    {
        hasMilk = true;
    }
    public void addSugar()
    {
        hasSugar = true;
    }
    public void addCaffein()
    {
        hasCaffein = true;
    }
    public CoffeeA()
    {
        this.name = "CoffeeA";
    }
}
