public class CoffeeC extends Coffee
{
    public void addMilk()
    {
        hasMilk = true;
    }
    public void addSugar()
    {
        hasSugar = true;
    }
    public void addCaffein()
    {
        hasCaffein = true;
    }
    public CoffeeC()
    {
        this.name = "CoffeeC";
    }
}
