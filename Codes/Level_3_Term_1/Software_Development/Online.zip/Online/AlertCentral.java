import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AlertCentral 
{

   public void updateMode(char mode) 
   {
	  //WRITE YOUR CODES HERE

   }

   public void startAlarm()
   {
	   //WRITE YOUR CODES HERE

   }

	JFrame jFrame;
	JButton jButton;
	JTextField jTextField;
		
   public AlertCentral()
   {
	   // TODO Auto-generated constructor stub
		jFrame = new JFrame("Alert Input");
		jFrame.setResizable(false);
		jFrame.setSize(200, 220);
		
		JPanel panel = new JPanel();
		jFrame.add(panel);		
		
		panel.setLayout(null);

		JLabel userLabel = new JLabel("Enter Command('S','L','V')");
		userLabel.setBounds(10, 10, 300, 25);
		panel.add(userLabel);

		 jTextField = new JTextField(20);
		 jTextField.setBounds(10, 40, 160, 25);
		panel.add(jTextField);

		jButton = new JButton("Update Mode");
		jButton.setBounds(10, 80, 160, 25);
		jButton.addActionListener(new UpdateModeButtonListener());
		panel.add(jButton);
		

		jButton = new JButton("Start Alarm");
		jButton.setBounds(10, 120, 160, 25);
		jButton.addActionListener(new StartAlarmButtonListener());
		panel.add(jButton);
		
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setVisible(true);
   }
   
   class StartAlarmButtonListener implements ActionListener 
   {
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			startAlarm();
		}
	}

   class UpdateModeButtonListener implements ActionListener 
   {
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			String input = jTextField.getText();
			
			try
			{
				updateMode(input.charAt(0));
				System.out.println("Command: "+input);
			}
			catch(Exception ex){;}
			
		}
	}
   
   
   public static void main(String[] args) {
	   new AlertCentral();
   }
}